package kr.nipa.javabeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.sql.DataSource;

public class Member {
	private int num;
	private String id;
	private String pwd;
	private String name;
	private String address;
	private String phone1;
	private String phone2;
	private String phone3;
	private String email_id;
	private String email_site;
	
	private String pageNumber;
	private int start;
	private int end;
	private int totalPage;
	
	ArrayList<Member> list = new ArrayList<Member>();
	
	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public String getPhone3() {
		return phone3;
	}
	public void setPhone3(String phone3) {
		this.phone3 = phone3;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getEmail_site() {
		return email_site;
	}
	public void setEmail_site(String email_site) {
		this.email_site = email_site;
	}
	public String getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	
	public ArrayList<Member> getMemberList() throws ServletException
	{
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			int pageNum = 0;
			if (pageNumber != null)
				pageNum = Integer.parseInt(pageNumber);
			
			Context initContext = new InitialContext();
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			DataSource ds = (DataSource)envContext.lookup("jdbc/TestDB");
	
			conn = ds.getConnection();
			
			final int PAGE_SIZE = 3;
			
			String totalList = "select count(*) from user";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(totalList);
			int totalCount = 0;
			if (rs.next())
				totalCount = rs.getInt(1)	;
			
			if (rs != null)
				rs.close();
	
			start = (pageNum - 1) * PAGE_SIZE;
			end = pageNum  * PAGE_SIZE;
			
			if (start < 0)
				start = 0;
			if (end > totalCount)
				end = totalCount;
			
			totalPage = totalCount / PAGE_SIZE + 1;
			
			String query = "select * from user where num between ? and ?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, start);
			ps.setInt(2, end);
				
			rs = ps.executeQuery();
			
			while (rs.next()) {
				Member member = new Member();
				
				member.setNum(rs.getInt("num"));
				member.setId(rs.getString("id"));
				member.setName(rs.getString("name"));
				member.setAddress(rs.getString("address"));
				member.setPhone1(rs.getString("phone1"));
				member.setPhone2(rs.getString("phone2"));
				member.setPhone3(rs.getString("phone3"));
				member.setEmail_id(rs.getString("email_id"));
				member.setEmail_site(rs.getString("email_site"));
				
				list.add(member);
			}
		} catch (Exception e) {
			throw new ServletException(e);
		} finally {
			try {
				if (rs != null)	rs.close();
				if (ps != null) ps.close();
				if (stmt != null) stmt.close();
				if (conn != null) conn.close();
			} catch (Exception e) {
				// ignore exception
			}
		}
		
		return list;
	}
}
